//
//  PrebidMobileUnity.h
//  PrebidMobileUnity
//
//  Created by Knorex on 2/20/25.
//

#import <Foundation/Foundation.h>

//! Project version number for PrebidMobileUnity.
FOUNDATION_EXPORT double PrebidMobileUnityVersionNumber;

//! Project version string for PrebidMobileUnity.
FOUNDATION_EXPORT const unsigned char PrebidMobileUnityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrebidMobileUnity/PublicHeader.h>


